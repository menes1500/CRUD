Prejeto feito pelo grupo 07.

Entidade implementada com sucesso, porém o menu de criaçao das respostas ainda está incompleto.

O menu em si está implementado porém está faltando os métodos.